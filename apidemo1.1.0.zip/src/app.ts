import { runApp } from 'rax-app';
import appConfig from './app.json';

runApp(appConfig);
