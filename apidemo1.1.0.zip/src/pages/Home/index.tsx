
import { createElement, useState } from "rax";
import View from 'rax-view';
import Cache from "./cache";
import Device from "./device";
import Gateway from "./gateway";
import Uiwindow from "./uiwindow";
import User from "./user";
import Window from "./window";
import Business from "./bussiness";
import "./css/index.css";


export default function jsBridgeDemo() {
  return (
    <View>
       <Cache />
       <Window />
       <User />
       <Device />
       <Business />
       <Uiwindow />
       <Gateway /> 
    </View>
  );
}